# System Prompt / Arsitektur Rekap PDP

Aplikasi ini adalah modul React tunggal untuk merekapitulasi data Persediaan Dalam Perjalanan (PDP) dari dua sheet SAP: `zrsd015` (Surat Jalan/PGI) dan `zrfi056` (Invoice/Nota).

## 1. Persyaratan Input (Struktur Excel)
Aplikasi mewajibkan file Excel (.xlsx) dengan dua sheet berikut:
*   **`zrsd015`**: Wajib memiliki kolom `Trans Date`, `Main SO Nbr.`, `Billing Nbr.`, `Material`, `Sales Description [Trs]`, `PGI. AUOM`, `SPM/SJ LastDate`, `SJ`, `SPM`, `SPM AUOM`.
*   **`zrfi056`**: Wajib memiliki kolom `Tgl Nota`, `SO`, `Material`, `Quantity`.

## 2. Aturan Bisnis & Logika Kalkulasi
Pengelompokan data dilakukan berdasarkan kombinasi `SO` dan `Material`.

### Deteksi Periode
*   **Bulan Ini**: Transaksi yang terjadi pada bulan laporan yang dipilih.
*   **Bulan Lalu**: Transaksi yang terjadi sebelum bulan laporan yang dipilih.

### Case Khusus: SO Lebih Muda dari SJ (`hasSoMuda`)
Jika tanggal transaksi SO (`Trans Date`) lebih besar/muda dibandingkan tanggal Surat Jalan (`SPM/SJ LastDate`), data ini dianggap sebagai anomali kebijakan khusus.
*   **Penanganan**: Seluruh kalkulasi selisih untuk case ini difokuskan di tabel "Bulan Ini" (Tabel Kiri) pada kolom **Langsung Nota**.
*   **Pencegahan Double Count**: Pada tabel "Bulan Lalu" (Tabel Kanan), nilai *Langsung Invoice* (kolom S) dan *Belum Invoice* (kolom T) **wajib diset menjadi 0** agar tidak dihitung ganda.

## 3. Format Export Excel (Penting untuk UI/UX)
File hasil export harus bernama `REKAP_[Bulan]_[Tahun].xlsx` dan berisi sheet `REKAP` dengan spesifikasi tata letak:
*   **Baris 1**: Kosong (Dihapus dari baris data awal, sehingga header langsung di baris 2).
*   **Baris 2 (Grouping Header)**: Berisi teks pengelompokan seperti `BULAN INI - OKTOBER`, `LANGSUNG NOTA`, `PDP MASUK`, dll.
*   **Baris 3 & 4 (Merged)**: Berisi nama kolom spesifik.
*   **Styling Header**:
    *   Warna background utama: Biru Muda (`FF9DDCF6`).
    *   Warna background pemisah (Kolom I / Index 9): Abu-abu Gelap (`FF404040`), tanpa border.
    *   Font: Bold, perataan tengah (horizontal & vertikal), teks dibungkus (*wrap text*).
    *   Border: Garis tipis (thin) di semua sisi (kecuali kolom pemisah).
*   **Format Angka**: Menggunakan format akuntansi standar `_-* #,##0_-;\-* #,##0_-;_-* "-"_-;_-@_-`.

## 4. Tech Stack
*   **Framework**: React (Vite / CRA).
*   **Parsing/Ekstraksi Data**: `xlsx` (SheetJS) untuk membaca data mentah dengan cepat.
*   **Manipulasi File & Styling**: `exceljs` untuk menghasilkan file output dengan format sel (warna, merge, width, format angka) yang kompleks.
*   **Pengunduhan**: `file-saver` (FileSaver.js).
*   **UI/Icons**: Tailwind CSS dan `lucide-react`.
